package com.statushd.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Typeface
import android.media.MediaCodecInfo
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.ui.PlayerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var mainScroll: ScrollView
    private lateinit var btnSettings: MaterialButton
    private lateinit var cardPickHero: LinearLayout
    private lateinit var btnPickVideo: MaterialButton
    private lateinit var cardWorkspace: LinearLayout
    private lateinit var tvVideoMeta: TextView
    private lateinit var btnChangeVideo: MaterialButton
    private lateinit var containerClipThumbnails: LinearLayout
    private lateinit var btnToggleEdit: MaterialButton
    private lateinit var layoutEditDrawer: LinearLayout
    private lateinit var playerView: PlayerView
    private lateinit var switchTrim: SwitchMaterial
    private lateinit var layoutTrimControls: LinearLayout
    private lateinit var tvStartTime: TextView
    private lateinit var tvEndTime: TextView
    private lateinit var seekStart: SeekBar
    private lateinit var seekEnd: SeekBar
    private lateinit var btnPreviewTrim: MaterialButton
    private lateinit var etCaption: EditText

    private lateinit var pill1080p: TextView
    private lateinit var pill720p: TextView
    private lateinit var pill30s: TextView
    private lateinit var pill60s: TextView
    private lateinit var pill90s: TextView
    private lateinit var tvSplitSummary: TextView

    private lateinit var btnOptimize: MaterialButton
    private lateinit var layoutProgress: LinearLayout
    private lateinit var tvProgressLabel: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnCancel: MaterialButton

    private lateinit var cardOutput: LinearLayout
    private lateinit var tvOutputHint: TextView
    private lateinit var containerParts: LinearLayout
    private lateinit var btnSendAllSelfChat: MaterialButton
    private lateinit var btnPushAllCloudApi: MaterialButton

    private var player: ExoPlayer? = null
    private var selectedUri: Uri? = null
    private var fullDurationMs: Long = 0L
    private var videoWidth: Int = 1080
    private var videoHeight: Int = 1920
    private var trimStartMs: Long = 0L
    private var trimEndMs: Long = 0L

    // PureStatus-style toggle states
    private var selectedShortSide: Int = 1080
    private var selectedSplitSec: Int = 30

    private var activeTransformer: Transformer? = null
    private var isCancelled: Boolean = false
    private val exportedParts = mutableListOf<ExportedPart>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val bgExecutor = Executors.newSingleThreadExecutor()
    private var thumbGenGeneration: Int = 0
    private var previewStopRunnable: Runnable? = null

    data class Segment(val startMs: Long, val endMs: Long)

    data class ExportedPart(
        val index: Int,
        val file: File,
        val galleryUri: Uri?,
        val durationMs: Long,
        val sizeBytes: Long
    )

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                loadSelectedVideo(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashLogger()
        setContentView(R.layout.activity_main)
        bindViews()
        setupListeners()
        updatePillStyles()
        showLastCrashIfAny()
    }

    private fun installCrashLogger() {
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                File(cacheDir, "last_crash.txt").writeText(
                    "${throwable.javaClass.name}: ${throwable.message}\n" +
                        throwable.stackTraceToString().take(2500)
                )
            } catch (_: Exception) {
            }
            prev?.uncaughtException(thread, throwable)
        }
    }

    private fun showLastCrashIfAny() {
        val f = File(cacheDir, "last_crash.txt")
        if (f.exists()) {
            val text = try { f.readText() } catch (_: Exception) { "" }
            f.delete()
            if (text.isNotBlank()) {
                AlertDialog.Builder(this)
                    .setTitle("Previous Error Log")
                    .setMessage(text.take(1200))
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    private fun bindViews() {
        mainScroll = findViewById(R.id.mainScroll)
        btnSettings = findViewById(R.id.btnSettings)
        cardPickHero = findViewById(R.id.cardPickHero)
        btnPickVideo = findViewById(R.id.btnPickVideo)
        cardWorkspace = findViewById(R.id.cardWorkspace)
        tvVideoMeta = findViewById(R.id.tvVideoMeta)
        btnChangeVideo = findViewById(R.id.btnChangeVideo)
        containerClipThumbnails = findViewById(R.id.containerClipThumbnails)
        btnToggleEdit = findViewById(R.id.btnToggleEdit)
        layoutEditDrawer = findViewById(R.id.layoutEditDrawer)
        playerView = findViewById(R.id.playerView)
        switchTrim = findViewById(R.id.switchTrim)
        layoutTrimControls = findViewById(R.id.layoutTrimControls)
        tvStartTime = findViewById(R.id.tvStartTime)
        tvEndTime = findViewById(R.id.tvEndTime)
        seekStart = findViewById(R.id.seekStart)
        seekEnd = findViewById(R.id.seekEnd)
        btnPreviewTrim = findViewById(R.id.btnPreviewTrim)
        etCaption = findViewById(R.id.etCaption)

        pill1080p = findViewById(R.id.pill1080p)
        pill720p = findViewById(R.id.pill720p)
        pill30s = findViewById(R.id.pill30s)
        pill60s = findViewById(R.id.pill60s)
        pill90s = findViewById(R.id.pill90s)
        tvSplitSummary = findViewById(R.id.tvSplitSummary)

        btnOptimize = findViewById(R.id.btnOptimize)
        layoutProgress = findViewById(R.id.layoutProgress)
        tvProgressLabel = findViewById(R.id.tvProgressLabel)
        progressBar = findViewById(R.id.progressBar)
        btnCancel = findViewById(R.id.btnCancel)

        cardOutput = findViewById(R.id.cardOutput)
        tvOutputHint = findViewById(R.id.tvOutputHint)
        containerParts = findViewById(R.id.containerParts)
        btnSendAllSelfChat = findViewById(R.id.btnSendAllSelfChat)
        btnPushAllCloudApi = findViewById(R.id.btnPushAllCloudApi)
    }

    private fun prefs() = getSharedPreferences("statushd_prefs", Context.MODE_PRIVATE)

    private fun isGpuClarityEnabled(): Boolean = prefs().getBoolean("gpu_clarity", true)
    private fun getSavedWhatsAppNumber(): String = prefs().getString("my_wa_number", "") ?: ""
    private fun getCloudPhoneId(): String = prefs().getString("cloud_phone_id", "") ?: ""
    private fun getCloudToken(): String = prefs().getString("cloud_token", "") ?: ""
    private fun getCloudApiVersion(): String = prefs().getString("cloud_api_version", "v25.0") ?: "v25.0"

    private fun isCloudApiConfigured(): Boolean {
        return getCloudPhoneId().isNotBlank() &&
            getCloudToken().isNotBlank() &&
            getSavedWhatsAppNumber().filter { it.isDigit() }.length >= 10
    }

    private fun setupListeners() {
        btnSettings.setOnClickListener { showSettingsDialog() }
        btnPickVideo.setOnClickListener { pickVideoLauncher.launch("video/*") }
        btnChangeVideo.setOnClickListener { pickVideoLauncher.launch("video/*") }

        btnToggleEdit.setOnClickListener {
            val opening = layoutEditDrawer.visibility != View.VISIBLE
            layoutEditDrawer.visibility = if (opening) View.VISIBLE else View.GONE
            btnToggleEdit.text = if (opening) "▲ Hide Edit / Trim" else "✂ Edit / Trim & Caption"
            if (opening) {
                selectedUri?.let { setupPlayer(it) }
            } else {
                releasePlayer()
            }
        }

        switchTrim.setOnCheckedChangeListener { _, isChecked ->
            layoutTrimControls.visibility = if (isChecked) View.VISIBLE else View.GONE
            updateSplitSummary()
            refreshClipThumbnails()
        }

        seekStart.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser || fullDurationMs <= 0L) return
                trimStartMs = (fullDurationMs * progress) / 1000L
                if (trimStartMs >= trimEndMs - 1000L) {
                    trimStartMs = max(0L, trimEndMs - 1000L)
                }
                tvStartTime.text = "Start: ${formatMs(trimStartMs)}"
                player?.seekTo(trimStartMs)
                updateSplitSummary()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { refreshClipThumbnails() }
        })

        seekEnd.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser || fullDurationMs <= 0L) return
                trimEndMs = (fullDurationMs * progress) / 1000L
                if (trimEndMs <= trimStartMs + 1000L) {
                    trimEndMs = min(fullDurationMs, trimStartMs + 1000L)
                }
                tvEndTime.text = "End: ${formatMs(trimEndMs)}"
                player?.seekTo(max(trimStartMs, trimEndMs - 1500L))
                updateSplitSummary()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { refreshClipThumbnails() }
        })

        btnPreviewTrim.setOnClickListener {
            val (s, e) = getActiveRange()
            playPreviewRange(s, e)
        }

        // Quality Pills
        pill1080p.setOnClickListener {
            selectedShortSide = 1080
            updatePillStyles()
            updateSplitSummary()
        }
        pill720p.setOnClickListener {
            selectedShortSide = 720
            updatePillStyles()
            updateSplitSummary()
        }

        // Split Time Pills
        pill30s.setOnClickListener {
            selectedSplitSec = 30
            updatePillStyles()
            updateSplitSummary()
            refreshClipThumbnails()
        }
        pill60s.setOnClickListener {
            selectedSplitSec = 60
            updatePillStyles()
            updateSplitSummary()
            refreshClipThumbnails()
        }
        pill90s.setOnClickListener {
            selectedSplitSec = 90
            updatePillStyles()
            updateSplitSummary()
            refreshClipThumbnails()
        }

        btnOptimize.setOnClickListener { startOptimization() }

        btnCancel.setOnClickListener {
            isCancelled = true
            try { activeTransformer?.cancel() } catch (_: Exception) {}
            activeTransformer = null
            finishProcessingUI()
            Toast.makeText(this, "Encoding cancelled", Toast.LENGTH_SHORT).show()
        }

        btnSendAllSelfChat.setOnClickListener {
            if (exportedParts.isNotEmpty()) {
                sendPartsToWhatsApp(exportedParts, toSelfChat = true)
            }
        }

        btnPushAllCloudApi.setOnClickListener {
            if (exportedParts.isNotEmpty()) {
                pushPartsViaCloudApi(exportedParts)
            }
        }
    }

    private fun updatePillStyles() {
        fun stylePill(tv: TextView, selected: Boolean) {
            tv.setBackgroundResource(if (selected) R.drawable.bg_pill_selected else R.drawable.bg_pill_unselected)
            tv.setTextColor(if (selected) 0xFF041B15.toInt() else getColor(R.color.text_muted))
        }
        stylePill(pill1080p, selectedShortSide == 1080)
        stylePill(pill720p, selectedShortSide == 720)
        stylePill(pill30s, selectedSplitSec == 30)
        stylePill(pill60s, selectedSplitSec == 60)
        stylePill(pill90s, selectedSplitSec == 90)
    }

    private fun showSettingsDialog() {
        val scroll = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 24)
        }

        val swClarity = SwitchMaterial(this).apply {
            text = "GPU Clarity Enhance (Unsharp Mask)"
            isChecked = isGpuClarityEnabled()
            setTextColor(getColor(R.color.text_primary))
        }
        container.addView(swClarity)

        fun addLabel(title: String) {
            val tv = TextView(this).apply {
                text = title
                setTextColor(getColor(R.color.accent_light))
                textSize = 12f
                setTypeface(null, Typeface.BOLD)
                setPadding(0, 24, 0, 6)
            }
            container.addView(tv)
        }

        addLabel("My WhatsApp Number (with country code, e.g. 919037744665)")
        val etPhone = EditText(this).apply {
            hint = "919037744665"
            inputType = InputType.TYPE_CLASS_PHONE
            setText(getSavedWhatsAppNumber())
        }
        container.addView(etPhone)

        addLabel("Meta Cloud API — Phone Number ID (Optional)")
        val etPhoneId = EditText(this).apply {
            hint = "e.g. 1625966173924168"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(getCloudPhoneId())
        }
        container.addView(etPhoneId)

        addLabel("Meta Cloud API — Access Token (Optional)")
        val etToken = EditText(this).apply {
            hint = "Paste permanent EAA... token"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            setText(getCloudToken())
        }
        container.addView(etToken)

        addLabel("Graph API Version")
        val etVersion = EditText(this).apply {
            hint = "v25.0"
            setText(getCloudApiVersion())
        }
        container.addView(etVersion)

        val note = TextView(this).apply {
            text = "Offline encoding works with zero internet. Fill in Meta Cloud API keys only if you want direct bot-to-chat HD delivery."
            setTextColor(getColor(R.color.text_muted))
            textSize = 11f
            setPadding(0, 18, 0, 0)
        }
        container.addView(note)
        scroll.addView(container)

        AlertDialog.Builder(this)
            .setTitle("Settings & Cloud API")
            .setView(scroll)
            .setPositiveButton("Save") { _, _ ->
                prefs().edit()
                    .putBoolean("gpu_clarity", swClarity.isChecked)
                    .putString("my_wa_number", etPhone.text.toString().filter { it.isDigit() })
                    .putString("cloud_phone_id", etPhoneId.text.toString().trim())
                    .putString("cloud_token", etToken.text.toString().trim())
                    .putString("cloud_api_version", etVersion.text.toString().trim().ifEmpty { "v25.0" })
                    .apply()
                updateSplitSummary()
                if (exportedParts.isNotEmpty()) {
                    renderOutputParts()
                }
                Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun playPreviewRange(startMs: Long, endMs: Long) {
        val p = player ?: return
        previewStopRunnable?.let { mainHandler.removeCallbacks(it) }
        p.seekTo(startMs)
        p.play()
        val r = Runnable {
            player?.pause()
        }
        previewStopRunnable = r
        mainHandler.postDelayed(r, max(500L, endMs - startMs))
    }

    private fun setupPlayer(uri: Uri) {
        releasePlayer()
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
        }
    }

    private fun releasePlayer() {
        previewStopRunnable?.let { mainHandler.removeCallbacks(it) }
        previewStopRunnable = null
        player?.release()
        player = null
        playerView.player = null
    }

    private fun loadSelectedVideo(uri: Uri) {
        selectedUri = uri
        releasePlayer()
        layoutEditDrawer.visibility = View.GONE
        btnToggleEdit.text = "✂ Edit / Trim & Caption"
        cardOutput.visibility = View.GONE
        exportedParts.clear()

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val wStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val hStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            val rotStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)

            fullDurationMs = durStr?.toLongOrNull() ?: 0L
            var w = wStr?.toIntOrNull() ?: 1080
            var h = hStr?.toIntOrNull() ?: 1920
            val rot = rotStr?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) {
                val tmp = w
                w = h
                h = tmp
            }
            videoWidth = w
            videoHeight = h
        } catch (e: Exception) {
            Toast.makeText(this, "Could not read video: ${e.message}", Toast.LENGTH_LONG).show()
            return
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }

        trimStartMs = 0L
        trimEndMs = fullDurationMs
        switchTrim.isChecked = false
        layoutTrimControls.visibility = View.GONE
        seekStart.max = 1000
        seekStart.progress = 0
        seekEnd.max = 1000
        seekEnd.progress = 1000
        tvStartTime.text = "Start: ${formatMs(0L)}"
        tvEndTime.text = "End: ${formatMs(fullDurationMs)}"

        val fileSizeMb = queryFileSize(uri) / (1024.0 * 1024.0)
        tvVideoMeta.text = String.format(
            Locale.US,
            "%d×%d • %s • %.1f MB",
            videoWidth,
            videoHeight,
            formatMs(fullDurationMs),
            fileSizeMb
        )

        cardPickHero.visibility = View.GONE
        cardWorkspace.visibility = View.VISIBLE

        updateSplitSummary()
        refreshClipThumbnails()
    }

    private fun refreshClipThumbnails() {
        val uri = selectedUri ?: return
        val segments = buildSegments()
        containerClipThumbnails.removeAllViews()
        if (segments.isEmpty()) return

        val gen = ++thumbGenGeneration
        val density = resources.displayMetrics.density
        val cardSizePx = (118 * density).toInt()
        val marginEndPx = (10 * density).toInt()

        val imageViews = mutableListOf<ImageView>()
        for ((idx, seg) in segments.withIndex()) {
            val frame = FrameLayout(this).apply {
                setBackgroundResource(R.drawable.bg_thumb_card)
                clipToOutline = true
                val lp = LinearLayout.LayoutParams(cardSizePx, cardSizePx)
                lp.marginEnd = marginEndPx
                layoutParams = lp
                setOnClickListener {
                    if (layoutEditDrawer.visibility != View.VISIBLE) {
                        layoutEditDrawer.visibility = View.VISIBLE
                        btnToggleEdit.text = "▲ Hide Edit / Trim"
                        setupPlayer(uri)
                    }
                    playPreviewRange(seg.startMs, seg.endMs)
                }
            }

            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            }
            imageViews.add(iv)
            frame.addView(iv)

            val durBadge = TextView(this).apply {
                text = formatMs(seg.endMs - seg.startMs)
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 11f
                setTypeface(null, Typeface.BOLD)
                setBackgroundResource(R.drawable.bg_time_badge)
                setPadding(12, 4, 12, 4)
                val lp = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.START
                )
                lp.setMargins(10, 0, 0, 10)
                layoutParams = lp
            }
            frame.addView(durBadge)

            if (segments.size > 1) {
                val partBadge = TextView(this).apply {
                    text = "P${idx + 1}"
                    setTextColor(0xFF06CF9C.toInt())
                    textSize = 10f
                    setTypeface(null, Typeface.BOLD)
                    setBackgroundResource(R.drawable.bg_time_badge)
                    setPadding(10, 3, 10, 3)
                    val lp = FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        FrameLayout.LayoutParams.WRAP_CONTENT,
                        Gravity.TOP or Gravity.END
                    )
                    lp.setMargins(0, 10, 10, 0)
                    layoutParams = lp
                }
                frame.addView(partBadge)
            }

            containerClipThumbnails.addView(frame)
        }

        // Decode clip thumbnails asynchronously
        bgExecutor.execute {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, uri)
                for ((idx, seg) in segments.withIndex()) {
                    if (gen != thumbGenGeneration) break
                    val sampleUs = (seg.startMs + min(1000L, (seg.endMs - seg.startMs) / 2)) * 1000L
                    val rawBmp: Bitmap? = retriever.getFrameAtTime(
                        sampleUs,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                    )
                    val scaled = rawBmp?.let {
                        val b = Bitmap.createScaledBitmap(it, 240, 240, true)
                        if (b != it) it.recycle()
                        b
                    }
                    if (scaled != null && gen == thumbGenGeneration) {
                        mainHandler.post {
                            if (gen == thumbGenGeneration && idx < imageViews.size) {
                                imageViews[idx].setImageBitmap(scaled)
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { retriever.release() } catch (_: Exception) {}
            }
        }
    }

    private fun queryFileSize(uri: Uri): Long {
        return try {
            contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    private fun getActiveRange(): Pair<Long, Long> {
        return if (switchTrim.isChecked) {
            Pair(trimStartMs, trimEndMs)
        } else {
            Pair(0L, fullDurationMs)
        }
    }

    private fun buildSegments(): List<Segment> {
        val (start, end) = getActiveRange()
        val total = end - start
        if (total <= 0L) return emptyList()
        val splitMs = selectedSplitSec * 1000L
        if (total <= splitMs + 1500L) {
            return listOf(Segment(start, end))
        }
        val list = mutableListOf<Segment>()
        var cursor = start
        while (cursor < end) {
            val remaining = end - cursor
            val nextEnd = if (remaining <= splitMs + 2500L) end else min(end, cursor + splitMs)
            list.add(Segment(cursor, nextEnd))
            cursor = nextEnd
        }
        return list
    }

    private fun computeVideoBitrateBps(shortSide: Int, durationMs: Long): Int {
        // Auto-cap each clip to <= 14.5 MB so it fits strictly under WhatsApp's 16 MB passthrough ceiling
        val targetMaxMb = 14.5
        val durSec = max(1.0, durationMs / 1000.0)
        val audioBps = 128_000.0
        val totalBps = (targetMaxMb * 1024.0 * 1024.0 * 8.0) / durSec
        val maxCap = if (shortSide <= 720) 3_500_000 else 4_500_000
        return (totalBps - audioBps).toInt().coerceIn(850_000, maxCap)
    }

    private fun updateSplitSummary() {
        if (fullDurationMs <= 0L) return
        val segments = buildSegments()
        if (segments.isEmpty()) return
        val firstDurMs = segments[0].endMs - segments[0].startMs
        val videoBps = computeVideoBitrateBps(selectedShortSide, firstDurMs)
        val estMb = ((videoBps + 128_000.0) * (firstDurMs / 1000.0)) / (8.0 * 1024.0 * 1024.0)
        val clarityTag = if (isGpuClarityEnabled()) " • Clarity ON" else ""
        val clipWord = if (segments.size == 1) "1 clip" else "${segments.size} clips"
        tvSplitSummary.text = String.format(
            Locale.US,
            "%s • %dp • %.1f Mbps • Est. ~%.1f MB/clip%s",
            clipWord,
            selectedShortSide,
            videoBps / 1_000_000.0,
            estMb,
            clarityTag
        )
        btnOptimize.text = if (segments.size == 1) {
            "Compress (No Watermark)"
        } else {
            "Compress ${segments.size} Clips (No Watermark)"
        }
    }

    private fun startOptimization() {
        val uri = selectedUri ?: return
        releasePlayer()

        val segments = buildSegments()
        if (segments.isEmpty()) return

        isCancelled = false
        exportedParts.clear()
        containerParts.removeAllViews()
        cardOutput.visibility = View.GONE
        btnSendAllSelfChat.visibility = View.GONE
        btnPushAllCloudApi.visibility = View.GONE

        btnOptimize.isEnabled = false
        btnChangeVideo.isEnabled = false
        layoutProgress.visibility = View.VISIBLE
        progressBar.progress = 0

        val exportDir = File(cacheDir, "exports").apply {
            if (!exists()) mkdirs()
            listFiles()?.forEach { it.delete() }
        }

        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        processSegmentAt(
            uri = uri,
            segments = segments,
            index = 0,
            exportDir = exportDir,
            timestamp = timestamp,
            useHighProfile = true,
            allowGpuSharpen = isGpuClarityEnabled()
        )
    }

    private fun processSegmentAt(
        uri: Uri,
        segments: List<Segment>,
        index: Int,
        exportDir: File,
        timestamp: String,
        useHighProfile: Boolean,
        allowGpuSharpen: Boolean
    ) {
        if (isCancelled) {
            finishProcessingUI()
            return
        }
        if (index >= segments.size) {
            onAllSegmentsFinished()
            return
        }

        try {
            val seg = segments[index]
            val partNum = index + 1
            val totalParts = segments.size
            val outFile = File(exportDir, "StatusHD_${timestamp}_Part${partNum}.mp4")
            if (outFile.exists()) outFile.delete()

            val mediaItem = MediaItem.Builder()
                .setUri(uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(seg.startMs)
                        .setEndPositionMs(seg.endMs)
                        .build()
                )
                .build()

            val videoEffects = mutableListOf<Effect>()
            val sourceShortSide = min(videoWidth, videoHeight)
            if (sourceShortSide > selectedShortSide) {
                videoEffects.add(Presentation.createForShortSide(selectedShortSide))
            }
            if (allowGpuSharpen) {
                videoEffects.add(UnsharpMaskEffect(sharpness = 0.60f))
            }
            videoEffects.add(FrameDropEffect.createDefaultFrameDropEffect(30f))

            val editedMediaItem = EditedMediaItem.Builder(mediaItem)
                .setEffects(Effects(emptyList(), videoEffects))
                .build()

            val settingsBuilder = VideoEncoderSettings.Builder()
                .setBitrate(computeVideoBitrateBps(selectedShortSide, seg.endMs - seg.startMs))
                .setBitrateMode(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                .setiFrameIntervalSeconds(2.0f)

            if (useHighProfile) {
                settingsBuilder.setEncodingProfileLevel(
                    MediaCodecInfo.CodecProfileLevel.AVCProfileHigh,
                    MediaCodecInfo.CodecProfileLevel.AVCLevel41
                )
            }

            val encoderFactory = DefaultEncoderFactory.Builder(this)
                .setRequestedVideoEncoderSettings(settingsBuilder.build())
                .setEnableFallback(true)
                .build()

            val progressHolder = ProgressHolder()
            var progressTicker: Runnable? = null

            val transformer = Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(encoderFactory)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        progressTicker?.let { mainHandler.removeCallbacks(it) }
                        activeTransformer = null
                        val savedGalleryUri = saveToGallery(outFile)
                        exportedParts.add(
                            ExportedPart(
                                index = partNum,
                                file = outFile,
                                galleryUri = savedGalleryUri,
                                durationMs = seg.endMs - seg.startMs,
                                sizeBytes = outFile.length()
                            )
                        )
                        processSegmentAt(
                            uri = uri,
                            segments = segments,
                            index = index + 1,
                            exportDir = exportDir,
                            timestamp = timestamp,
                            useHighProfile = useHighProfile,
                            allowGpuSharpen = allowGpuSharpen
                        )
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        progressTicker?.let { mainHandler.removeCallbacks(it) }
                        activeTransformer = null
                        if (useHighProfile) {
                            tvProgressLabel.text = "Retrying Clip $partNum (Standard H.264)..."
                            processSegmentAt(uri, segments, index, exportDir, timestamp, useHighProfile = false, allowGpuSharpen = allowGpuSharpen)
                            return
                        }
                        if (allowGpuSharpen) {
                            tvProgressLabel.text = "Retrying Clip $partNum (Without GPU Shader)..."
                            processSegmentAt(uri, segments, index, exportDir, timestamp, useHighProfile = false, allowGpuSharpen = false)
                            return
                        }
                        finishProcessingUI()
                        AlertDialog.Builder(this@MainActivity)
                            .setTitle("Export Error (Clip $partNum)")
                            .setMessage(exportException.message ?: "Unknown hardware encoder error")
                            .setPositiveButton("OK", null)
                            .show()
                    }
                })
                .build()

            activeTransformer = transformer
            tvProgressLabel.text = "Compressing Clip $partNum of $totalParts... 0%"
            progressBar.progress = 0
            transformer.start(editedMediaItem, outFile.absolutePath)

            progressTicker = object : Runnable {
                override fun run() {
                    val t = activeTransformer ?: return
                    try {
                        val state = t.getProgress(progressHolder)
                        if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                            val pct = progressHolder.progress.coerceIn(0, 100)
                            progressBar.progress = pct
                            tvProgressLabel.text = "Compressing Clip $partNum of $totalParts... $pct%"
                        }
                        if (state != Transformer.PROGRESS_STATE_NOT_STARTED) {
                            mainHandler.postDelayed(this, 200)
                        }
                    } catch (_: Exception) {}
                }
            }
            mainHandler.postDelayed(progressTicker, 250)
        } catch (t: Throwable) {
            activeTransformer = null
            if (useHighProfile) {
                processSegmentAt(uri, segments, index, exportDir, timestamp, useHighProfile = false, allowGpuSharpen = allowGpuSharpen)
                return
            }
            if (allowGpuSharpen) {
                processSegmentAt(uri, segments, index, exportDir, timestamp, useHighProfile = false, allowGpuSharpen = false)
                return
            }
            finishProcessingUI()
            AlertDialog.Builder(this)
                .setTitle("Encoding Error")
                .setMessage("${t.javaClass.simpleName}: ${t.message}")
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun saveToGallery(file: File): Uri? {
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/StatusHD")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(file).use { input -> input.copyTo(out) }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            }
            uri
        } catch (_: Exception) {
            null
        }
    }

    private fun onAllSegmentsFinished() {
        finishProcessingUI()
        renderOutputParts()
        Toast.makeText(
            this,
            "Done! ${exportedParts.size} HD clip(s) saved to Gallery.",
            Toast.LENGTH_LONG
        ).show()
        mainHandler.postDelayed({ mainScroll.fullScroll(View.FOCUS_DOWN) }, 150)
    }

    private fun renderOutputParts() {
        cardOutput.visibility = View.VISIBLE
        containerParts.removeAllViews()
        val cloudReady = isCloudApiConfigured()
        tvOutputHint.text = if (cloudReady) {
            "Cloud API ready! Tap Push via Cloud API for direct bot delivery, or Send to My Chat offline."
        } else {
            "Tap Send to My Chat → tap HD at top (if shown) → Forward to My Status. (Add Meta Cloud API keys in ⚙ Settings anytime.)"
        }

        for (part in exportedParts) {
            val block = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(R.drawable.bg_subcard)
                setPadding(24, 20, 24, 20)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = 16
                layoutParams = lp
            }

            val sizeMb = part.sizeBytes / (1024.0 * 1024.0)
            val durSec = max(0.1, part.durationMs / 1000.0)
            val actualMbps = (part.sizeBytes * 8.0 / durSec) / 1_000_000.0
            val info = TextView(this).apply {
                text = String.format(
                    Locale.US,
                    "Clip %d • %s • %.2f MB (~%.2f Mbps)",
                    part.index,
                    formatMs(part.durationMs),
                    sizeMb,
                    actualMbps
                )
                setTextColor(getColor(R.color.text_primary))
                textSize = 13f
                setTypeface(null, Typeface.BOLD)
            }

            val btnRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = 12
                layoutParams = lp
            }

            val btnSelfChat = MaterialButton(this).apply {
                text = "Send to My Chat"
                isAllCaps = false
                setBackgroundColor(getColor(R.color.accent))
                setTextColor(0xFF041B15.toInt())
                textSize = 12f
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f)
                lp.marginEnd = 10
                layoutParams = lp
                setOnClickListener { sendPartsToWhatsApp(listOf(part), toSelfChat = true) }
            }

            val btnShareAny = MaterialButton(this).apply {
                text = "Share WA"
                isAllCaps = false
                setBackgroundColor(getColor(R.color.border_dark))
                setTextColor(getColor(R.color.text_primary))
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { sendPartsToWhatsApp(listOf(part), toSelfChat = false) }
            }

            btnRow.addView(btnSelfChat)
            btnRow.addView(btnShareAny)
            block.addView(info)
            block.addView(btnRow)

            if (cloudReady) {
                val btnCloud = MaterialButton(this).apply {
                    text = "Push Clip ${part.index} via Meta Cloud API"
                    isAllCaps = false
                    setBackgroundColor(getColor(R.color.accent_purple))
                    setTextColor(getColor(R.color.text_primary))
                    textSize = 12f
                    val lp = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    lp.topMargin = 8
                    layoutParams = lp
                    setOnClickListener { pushPartsViaCloudApi(listOf(part)) }
                }
                block.addView(btnCloud)
            }

            containerParts.addView(block)
        }

        btnSendAllSelfChat.visibility = if (exportedParts.size > 1) View.VISIBLE else View.GONE
        btnPushAllCloudApi.visibility = if (exportedParts.size > 1 && cloudReady) View.VISIBLE else View.GONE
    }

    private fun pushPartsViaCloudApi(parts: List<ExportedPart>) {
        if (!isCloudApiConfigured()) {
            showSettingsDialog()
            return
        }
        val phoneId = getCloudPhoneId()
        val token = getCloudToken()
        val recipient = getSavedWhatsAppNumber()
        val version = getCloudApiVersion()
        val caption = etCaption.text.toString().trim()

        val progressDialog = AlertDialog.Builder(this)
            .setTitle("Meta Cloud API")
            .setMessage("Preparing upload...")
            .setCancelable(false)
            .create()
        progressDialog.show()

        bgExecutor.execute {
            val errors = mutableListOf<String>()
            var sentCount = 0
            for (part in parts) {
                val partCaption = if (parts.size > 1 && caption.isNotEmpty()) {
                    "$caption (${part.index}/${parts.size})"
                } else {
                    caption
                }
                val result = WhatsAppCloudApi.uploadAndSendVideo(
                    file = part.file,
                    phoneNumberId = phoneId,
                    accessToken = token,
                    recipientNumber = recipient,
                    caption = partCaption,
                    apiVersion = version
                ) { status ->
                    mainHandler.post {
                        progressDialog.setMessage("Clip ${part.index}/${parts.size}: $status")
                    }
                }
                if (result.success) {
                    sentCount++
                } else {
                    errors.add("Clip ${part.index}: ${result.errorMessage}")
                }
            }

            mainHandler.post {
                progressDialog.dismiss()
                if (errors.isEmpty()) {
                    AlertDialog.Builder(this)
                        .setTitle("Sent to Your WhatsApp Chat!")
                        .setMessage("$sentCount HD clip(s) delivered via Meta Cloud API. Open WhatsApp and Forward → My Status.")
                        .setPositiveButton("OK", null)
                        .show()
                } else {
                    AlertDialog.Builder(this)
                        .setTitle("Cloud API Error")
                        .setMessage(errors.joinToString("\n\n"))
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        }
    }

    private fun finishProcessingUI() {
        btnOptimize.isEnabled = true
        btnChangeVideo.isEnabled = true
        layoutProgress.visibility = View.GONE
    }

    private fun copyCaptionIfPresent(): String {
        val text = etCaption.text.toString().trim()
        if (text.isNotEmpty()) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("WhatsApp Status", text))
        }
        return text
    }

    private fun resolveShareUri(part: ExportedPart): Uri {
        return part.galleryUri ?: FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            part.file
        )
    }

    private fun detectWhatsAppPackage(): String? {
        val pkgs = listOf("com.whatsapp", "com.whatsapp.w4b")
        for (p in pkgs) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    packageManager.getPackageInfo(p, PackageManager.PackageInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    packageManager.getPackageInfo(p, 0)
                }
                return p
            } catch (_: Exception) {}
        }
        return null
    }

    private fun sendPartsToWhatsApp(parts: List<ExportedPart>, toSelfChat: Boolean) {
        if (parts.isEmpty()) return
        val caption = copyCaptionIfPresent()
        val waPkg = detectWhatsAppPackage()
        val uris = ArrayList<Uri>(parts.map { resolveShareUri(it) })

        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uris[0])
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "video/mp4"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            }
        }

        if (caption.isNotEmpty()) {
            intent.putExtra(Intent.EXTRA_TEXT, caption)
        }
        if (toSelfChat) {
            val num = getSavedWhatsAppNumber().filter { it.isDigit() }
            if (num.length >= 10) {
                intent.putExtra("jid", "${num}@s.whatsapp.net")
            }
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        if (waPkg != null) {
            intent.setPackage(waPkg)
        }

        try {
            startActivity(if (waPkg != null) intent else Intent.createChooser(intent, "Share to WhatsApp"))
        } catch (_: Exception) {
            intent.setPackage(null)
            try {
                startActivity(Intent.createChooser(intent, "Share to WhatsApp"))
            } catch (e: Exception) {
                Toast.makeText(this, "No WhatsApp app found: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun formatMs(ms: Long): String {
        val totalSec = max(0L, ms / 1000L)
        val mins = totalSec / 60L
        val secs = totalSec % 60L
        return String.format(Locale.US, "%d:%02d", mins, secs)
    }

    override fun onDestroy() {
        releasePlayer()
        bgExecutor.shutdownNow()
        super.onDestroy()
    }
}

package com.statushd.app

import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

object WhatsAppCloudApi {

    data class SendResult(
        val success: Boolean,
        val mediaId: String? = null,
        val messageId: String? = null,
        val errorMessage: String? = null
    )

    fun uploadAndSendVideo(
        file: File,
        phoneNumberId: String,
        accessToken: String,
        recipientNumber: String,
        caption: String,
        apiVersion: String = "v25.0",
        onStatus: (String) -> Unit
    ): SendResult {
        val cleanPhoneId = phoneNumberId.trim()
        val cleanToken = accessToken.trim()
        val cleanRecipient = recipientNumber.filter { it.isDigit() }
        val cleanVersion = apiVersion.trim().ifEmpty { "v25.0" }

        if (cleanPhoneId.isEmpty() || cleanToken.isEmpty() || cleanRecipient.length < 10) {
            return SendResult(
                success = false,
                errorMessage = "Missing Cloud API settings. Tap the Settings button at top-right to enter Phone Number ID, Access Token, and your WhatsApp number."
            )
        }

        if (file.length() > 16L * 1024L * 1024L) {
            return SendResult(
                success = false,
                errorMessage = "File exceeds Meta's 16 MB video limit. Try 30s split or 720p."
            )
        }

        // Step 1: Upload MP4 to /{phone-number-id}/media
        onStatus("Uploading to Meta Cloud API...")
        val uploadResult = uploadMedia(file, cleanPhoneId, cleanToken, cleanVersion)
        if (!uploadResult.first) {
            return SendResult(success = false, errorMessage = uploadResult.second)
        }
        val mediaId = uploadResult.second

        // Step 2: Send video message to recipient chat
        onStatus("Delivering HD video to your WhatsApp chat...")
        return sendVideoMessage(
            phoneNumberId = cleanPhoneId,
            accessToken = cleanToken,
            recipientNumber = cleanRecipient,
            mediaId = mediaId,
            caption = caption,
            apiVersion = cleanVersion
        )
    }

    private fun uploadMedia(
        file: File,
        phoneNumberId: String,
        accessToken: String,
        apiVersion: String
    ): Pair<Boolean, String> {
        val boundary = "----StatusHDBoundary${UUID.randomUUID().toString().replace("-", "")}"
        val lineEnd = "\r\n"
        val twoHyphens = "--"

        val url = URL("https://graph.facebook.com/$apiVersion/$phoneNumberId/media")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doInput = true
            doOutput = true
            useCaches = false
            connectTimeout = 30_000
            readTimeout = 120_000
            setRequestProperty("Authorization", "Bearer $accessToken")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }

        return try {
            DataOutputStream(conn.outputStream).use { out ->
                // Field: messaging_product=whatsapp
                out.writeBytes("$twoHyphens$boundary$lineEnd")
                out.writeBytes("Content-Disposition: form-data; name=\"messaging_product\"$lineEnd$lineEnd")
                out.writeBytes("whatsapp$lineEnd")

                // Field: type=video/mp4
                out.writeBytes("$twoHyphens$boundary$lineEnd")
                out.writeBytes("Content-Disposition: form-data; name=\"type\"$lineEnd$lineEnd")
                out.writeBytes("video/mp4$lineEnd")

                // Field: file
                out.writeBytes("$twoHyphens$boundary$lineEnd")
                out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"${file.name}\"$lineEnd")
                out.writeBytes("Content-Type: video/mp4$lineEnd$lineEnd")

                FileInputStream(file).use { fis ->
                    val buffer = ByteArray(16 * 1024)
                    var bytesRead: Int
                    while (fis.read(buffer).also { bytesRead = it } != -1) {
                        out.write(buffer, 0, bytesRead)
                    }
                }
                out.writeBytes(lineEnd)
                out.writeBytes("$twoHyphens$boundary$twoHyphens$lineEnd")
                out.flush()
            }

            val code = conn.responseCode
            val body = readResponse(conn, code)
            if (code in 200..299) {
                val id = JSONObject(body).optString("id", "")
                if (id.isNotEmpty()) {
                    Pair(true, id)
                } else {
                    Pair(false, "Upload succeeded but no media ID returned: $body")
                }
            } else {
                Pair(false, parseMetaError(code, body))
            }
        } catch (e: Exception) {
            Pair(false, "Upload failed: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            conn.disconnect()
        }
    }

    private fun sendVideoMessage(
        phoneNumberId: String,
        accessToken: String,
        recipientNumber: String,
        mediaId: String,
        caption: String,
        apiVersion: String
    ): SendResult {
        val url = URL("https://graph.facebook.com/$apiVersion/$phoneNumberId/messages")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doInput = true
            doOutput = true
            useCaches = false
            connectTimeout = 30_000
            readTimeout = 60_000
            setRequestProperty("Authorization", "Bearer $accessToken")
            setRequestProperty("Content-Type", "application/json")
        }

        return try {
            val videoObj = JSONObject().apply {
                put("id", mediaId)
                if (caption.isNotBlank()) {
                    put("caption", caption.take(1024))
                }
            }
            val payload = JSONObject().apply {
                put("messaging_product", "whatsapp")
                put("recipient_type", "individual")
                put("to", recipientNumber)
                put("type", "video")
                put("video", videoObj)
            }

            conn.outputStream.use { os ->
                os.write(payload.toString().toByteArray(Charsets.UTF_8))
                os.flush()
            }

            val code = conn.responseCode
            val body = readResponse(conn, code)
            if (code in 200..299) {
                val json = JSONObject(body)
                val messages = json.optJSONArray("messages")
                val msgId = if (messages != null && messages.length() > 0) {
                    messages.getJSONObject(0).optString("id", "")
                } else {
                    ""
                }
                SendResult(success = true, mediaId = mediaId, messageId = msgId)
            } else {
                SendResult(success = false, mediaId = mediaId, errorMessage = parseMetaError(code, body))
            }
        } catch (e: Exception) {
            SendResult(success = false, mediaId = mediaId, errorMessage = "Send failed: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            conn.disconnect()
        }
    }

    private fun readResponse(conn: HttpURLConnection, code: Int): String {
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        if (stream == null) return ""
        return BufferedReader(InputStreamReader(stream)).use { it.readText() }
    }

    private fun parseMetaError(code: Int, body: String): String {
        return try {
            val err = JSONObject(body).optJSONObject("error")
            if (err != null) {
                val errCode = err.optInt("code", code)
                val msg = err.optString("message", body)
                "Meta Error $errCode: $msg"
            } else {
                "HTTP $code: $body"
            }
        } catch (_: Exception) {
            "HTTP $code: $body"
        }
    }
}

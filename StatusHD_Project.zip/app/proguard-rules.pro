# Keep Media3 classes intact
-keep class androidx.media3.** { *; }

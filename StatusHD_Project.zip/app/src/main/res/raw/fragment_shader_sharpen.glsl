#version 100
precision highp float;
uniform sampler2D uTexSampler;
uniform float uTexelWidth;
uniform float uTexelHeight;
uniform float uSharpness;
varying vec2 vTexSamplingCoord;

void main() {
  vec4 center = texture2D(uTexSampler, vTexSamplingCoord);
  vec3 c = center.rgb;
  vec3 n = texture2D(uTexSampler, vTexSamplingCoord + vec2(0.0, uTexelHeight)).rgb;
  vec3 s = texture2D(uTexSampler, vTexSamplingCoord - vec2(0.0, uTexelHeight)).rgb;
  vec3 e = texture2D(uTexSampler, vTexSamplingCoord + vec2(uTexelWidth, 0.0)).rgb;
  vec3 w = texture2D(uTexSampler, vTexSamplingCoord - vec2(uTexelWidth, 0.0)).rgb;

  vec3 blur = (n + s + e + w) * 0.25;
  vec3 detail = c - blur;

  // Contrast-adaptive mask prevents halos around bright flashing stage lights
  vec3 minRgb = min(c, min(min(n, s), min(e, w)));
  vec3 maxRgb = max(c, max(max(n, s), max(e, w)));
  vec3 contrast = maxRgb - minRgb;
  float maxContrast = max(contrast.r, max(contrast.g, contrast.b));
  float edgeMask = 1.0 - smoothstep(0.25, 0.75, maxContrast);
  float gain = uSharpness * (0.35 + 0.65 * edgeMask);

  vec3 sharpened = clamp(c + detail * gain, 0.0, 1.0);
  gl_FragColor = vec4(sharpened, center.a);
}

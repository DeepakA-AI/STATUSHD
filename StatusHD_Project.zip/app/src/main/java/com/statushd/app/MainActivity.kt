package com.statushd.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.ui.PlayerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var mainScroll: ScrollView
    private lateinit var btnPickVideo: MaterialButton
    private lateinit var tvVideoInfo: TextView

    private lateinit var cardTrim: LinearLayout
    private lateinit var playerView: PlayerView
    private lateinit var switchManualTrim: SwitchMaterial
    private lateinit var layoutTrimControls: LinearLayout
    private lateinit var tvStartTime: TextView
    private lateinit var tvEndTime: TextView
    private lateinit var seekStart: SeekBar
    private lateinit var seekEnd: SeekBar
    private lateinit var btnSetStartNow: MaterialButton
    private lateinit var btnSetEndNow: MaterialButton
    private lateinit var btnCheckStart: MaterialButton
    private lateinit var btnCheckEnd: MaterialButton

    private lateinit var cardSettings: LinearLayout
    private lateinit var rgQuality: RadioGroup
    private lateinit var rgSplit: RadioGroup
    private lateinit var tvSplitSummary: TextView
    private lateinit var etCaption: EditText
    private lateinit var btnOptimize: MaterialButton
    private lateinit var layoutProgress: LinearLayout
    private lateinit var tvProgressLabel: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnCancel: MaterialButton

    private lateinit var cardOutput: LinearLayout
    private lateinit var containerParts: LinearLayout
    private lateinit var btnShareAll: MaterialButton

    private var player: ExoPlayer? = null
    private var selectedUri: Uri? = null
    private var fullDurationMs: Long = 0L
    private var videoWidth: Int = 0
    private var videoHeight: Int = 0
    private var trimStartMs: Long = 0L
    private var trimEndMs: Long = 0L

    private var activeTransformer: Transformer? = null
    private var isCancelled = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private var previewStopRunnable: Runnable? = null

    data class Segment(val startMs: Long, val endMs: Long)
    data class ExportedPart(val index: Int, val file: File, val durationMs: Long, val sizeBytes: Long)

    private val exportedParts = mutableListOf<ExportedPart>()

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                loadSelectedVideo(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupListeners()
    }

    private fun bindViews() {
        mainScroll = findViewById(R.id.mainScroll)
        btnPickVideo = findViewById(R.id.btnPickVideo)
        tvVideoInfo = findViewById(R.id.tvVideoInfo)

        cardTrim = findViewById(R.id.cardTrim)
        playerView = findViewById(R.id.playerView)
        switchManualTrim = findViewById(R.id.switchManualTrim)
        layoutTrimControls = findViewById(R.id.layoutTrimControls)
        tvStartTime = findViewById(R.id.tvStartTime)
        tvEndTime = findViewById(R.id.tvEndTime)
        seekStart = findViewById(R.id.seekStart)
        seekEnd = findViewById(R.id.seekEnd)
        btnSetStartNow = findViewById(R.id.btnSetStartNow)
        btnSetEndNow = findViewById(R.id.btnSetEndNow)
        btnCheckStart = findViewById(R.id.btnCheckStart)
        btnCheckEnd = findViewById(R.id.btnCheckEnd)

        cardSettings = findViewById(R.id.cardSettings)
        rgQuality = findViewById(R.id.rgQuality)
        rgSplit = findViewById(R.id.rgSplit)
        tvSplitSummary = findViewById(R.id.tvSplitSummary)
        etCaption = findViewById(R.id.etCaption)
        btnOptimize = findViewById(R.id.btnOptimize)
        layoutProgress = findViewById(R.id.layoutProgress)
        tvProgressLabel = findViewById(R.id.tvProgressLabel)
        progressBar = findViewById(R.id.progressBar)
        btnCancel = findViewById(R.id.btnCancel)

        cardOutput = findViewById(R.id.cardOutput)
        containerParts = findViewById(R.id.containerParts)
        btnShareAll = findViewById(R.id.btnShareAll)
    }

    private fun setupListeners() {
        btnPickVideo.setOnClickListener {
            pickVideoLauncher.launch("video/*")
        }

        switchManualTrim.setOnCheckedChangeListener { _, isChecked ->
            layoutTrimControls.visibility = if (isChecked) View.VISIBLE else View.GONE
            updateSplitSummary()
        }

        seekStart.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val proposed = progress.toLong() * 100L
                trimStartMs = min(proposed, max(0L, trimEndMs - 500L))
                tvStartTime.text = formatMs(trimStartMs)
                player?.pause()
                player?.seekTo(trimStartMs)
                updateSplitSummary()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        seekEnd.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val proposed = progress.toLong() * 100L
                trimEndMs = max(proposed, min(fullDurationMs, trimStartMs + 500L))
                tvEndTime.text = formatMs(trimEndMs)
                player?.pause()
                player?.seekTo(trimEndMs)
                updateSplitSummary()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        btnSetStartNow.setOnClickListener {
            val pos = player?.currentPosition ?: return@setOnClickListener
            if (pos < trimEndMs - 500L) {
                trimStartMs = pos
                seekStart.progress = (trimStartMs / 100L).toInt()
                tvStartTime.text = formatMs(trimStartMs)
                updateSplitSummary()
            } else {
                Toast.makeText(this, "Start must be before End", Toast.LENGTH_SHORT).show()
            }
        }

        btnSetEndNow.setOnClickListener {
            val pos = player?.currentPosition ?: return@setOnClickListener
            if (pos > trimStartMs + 500L) {
                trimEndMs = pos
                seekEnd.progress = (trimEndMs / 100L).toInt()
                tvEndTime.text = formatMs(trimEndMs)
                updateSplitSummary()
            } else {
                Toast.makeText(this, "End must be after Start", Toast.LENGTH_SHORT).show()
            }
        }

        btnCheckStart.setOnClickListener {
            val stopAt = min(trimEndMs, trimStartMs + 5000L)
            playPreviewRange(trimStartMs, stopAt)
        }

        btnCheckEnd.setOnClickListener {
            val startAt = max(trimStartMs, trimEndMs - 4000L)
            playPreviewRange(startAt, trimEndMs)
        }

        rgSplit.setOnCheckedChangeListener { _, _ -> updateSplitSummary() }
        rgQuality.setOnCheckedChangeListener { _, _ -> updateSplitSummary() }

        btnOptimize.setOnClickListener {
            startOptimization()
        }

        btnCancel.setOnClickListener {
            isCancelled = true
            activeTransformer?.cancel()
            activeTransformer = null
            finishProcessingUI()
            Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
        }

        btnShareAll.setOnClickListener {
            shareMultipleToWhatsApp(exportedParts.map { it.file })
        }
    }

    private fun playPreviewRange(startMs: Long, endMs: Long) {
        val exo = player ?: return
        previewStopRunnable?.let { mainHandler.removeCallbacks(it) }
        exo.seekTo(startMs)
        exo.play()
        val duration = max(300L, endMs - startMs)
        val stopTask = Runnable {
            exo.pause()
        }
        previewStopRunnable = stopTask
        mainHandler.postDelayed(stopTask, duration)
    }

    private fun loadSelectedVideo(uri: Uri) {
        selectedUri = uri
        cardOutput.visibility = View.GONE

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            fullDurationMs =
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                    ?: 0L
            val w =
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
                    ?: 1080
            val h =
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
                    ?: 1920
            val rot =
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull()
                    ?: 0
            if (rot == 90 || rot == 270) {
                videoWidth = h
                videoHeight = w
            } else {
                videoWidth = w
                videoHeight = h
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Could not read video metadata: ${e.message}", Toast.LENGTH_LONG).show()
            return
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }

        val sizeBytes = queryFileSize(uri)
        val sizeMb = sizeBytes / (1024.0 * 1024.0)
        tvVideoInfo.text = String.format(
            Locale.US,
            "Loaded: %.2f MB • %s • %dx%d",
            sizeMb,
            formatMs(fullDurationMs),
            videoWidth,
            videoHeight
        )

        trimStartMs = 0L
        trimEndMs = fullDurationMs
        val maxTicks = max(1, (fullDurationMs / 100L).toInt())
        seekStart.max = maxTicks
        seekEnd.max = maxTicks
        seekStart.progress = 0
        seekEnd.progress = maxTicks
        tvStartTime.text = formatMs(trimStartMs)
        tvEndTime.text = formatMs(trimEndMs)

        // Setup ExoPlayer
        player?.release()
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
        }

        cardTrim.visibility = View.VISIBLE
        cardSettings.visibility = View.VISIBLE
        updateSplitSummary()
    }

    private fun queryFileSize(uri: Uri): Long {
        return try {
            contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    private fun getActiveRange(): Pair<Long, Long> {
        return if (switchManualTrim.isChecked) {
            Pair(trimStartMs, max(trimStartMs + 500L, trimEndMs))
        } else {
            Pair(0L, fullDurationMs)
        }
    }

    private fun getSplitLengthMs(): Long {
        return when (rgSplit.checkedRadioButtonId) {
            R.id.rbSplit90 -> 90_000L
            R.id.rbSplit60 -> 60_000L
            R.id.rbSplit30 -> 30_000L
            else -> Long.MAX_VALUE
        }
    }

    private fun buildSegments(): List<Segment> {
        val (startMs, endMs) = getActiveRange()
        val totalMs = max(500L, endMs - startMs)
        val splitMs = getSplitLengthMs()
        if (splitMs == Long.MAX_VALUE || totalMs <= splitMs) {
            return listOf(Segment(startMs, endMs))
        }
        val list = mutableListOf<Segment>()
        var cursor = startMs
        while (cursor < endMs) {
            val nextEnd = min(cursor + splitMs, endMs)
            // Avoid tiny <1s trailing sliver by merging into previous part if needed
            if (endMs - nextEnd in 1..999 && list.isNotEmpty()) {
                list.add(Segment(cursor, endMs))
                break
            }
            list.add(Segment(cursor, nextEnd))
            cursor = nextEnd
        }
        return list
    }

    private fun updateSplitSummary() {
        if (fullDurationMs <= 0L) return
        val segments = buildSegments()
        val (_, targetMb) = getQualitySpec()
        if (segments.size == 1) {
            val dur = segments[0].endMs - segments[0].startMs
            tvSplitSummary.text = String.format(
                Locale.US,
                "Output: 1 HD Video (%s) • Target ≤ %.1f MB",
                formatMs(dur),
                targetMb
            )
            btnOptimize.text = "Create HD WhatsApp Status"
        } else {
            val detail = segments.mapIndexed { idx, seg ->
                "P${idx + 1}(${formatMs(seg.startMs)}–${formatMs(seg.endMs)})"
            }.joinToString(", ")
            tvSplitSummary.text = "Output: ${segments.size} HD Parts — $detail"
            btnOptimize.text = "Create ${segments.size} HD Status Parts"
        }
    }

    private fun getQualitySpec(): Pair<Int, Double> {
        return when (rgQuality.checkedRadioButtonId) {
            R.id.rb1080 -> Pair(1080, 15.0)
            R.id.rb720 -> Pair(720, 13.0)
            else -> Pair(720, 10.0)
        }
    }

    private fun startOptimization() {
        val uri = selectedUri ?: return
        player?.pause()

        val segments = buildSegments()
        if (segments.isEmpty()) return

        isCancelled = false
        exportedParts.clear()
        containerParts.removeAllViews()
        cardOutput.visibility = View.GONE
        btnShareAll.visibility = View.GONE

        btnOptimize.isEnabled = false
        btnPickVideo.isEnabled = false
        layoutProgress.visibility = View.VISIBLE
        progressBar.progress = 0

        val exportDir = File(cacheDir, "exports").apply {
            if (!exists()) mkdirs()
            listFiles()?.forEach { it.delete() }
        }

        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        processSegmentAt(uri, segments, 0, exportDir, timestamp)
    }

    private fun processSegmentAt(
        uri: Uri,
        segments: List<Segment>,
        index: Int,
        exportDir: File,
        timestamp: String
    ) {
        if (isCancelled) {
            finishProcessingUI()
            return
        }
        if (index >= segments.size) {
            onAllSegmentsFinished()
            return
        }

        val seg = segments[index]
        val partNum = index + 1
        val totalParts = segments.size
        val segDurSec = max(1.0, (seg.endMs - seg.startMs) / 1000.0)

        val (targetShortSide, targetMb) = getQualitySpec()
        val audioBps = 128_000.0
        val targetTotalBps = (targetMb * 1024.0 * 1024.0 * 8.0) / segDurSec
        val videoBps = (targetTotalBps - audioBps).toInt().coerceIn(900_000, 4_500_000)

        val outFile = File(exportDir, "StatusHD_${timestamp}_Part${partNum}.mp4")

        val mediaItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(seg.startMs)
                    .setEndPositionMs(seg.endMs)
                    .build()
            )
            .build()

        val videoEffects = mutableListOf<Effect>()
        val sourceShortSide = min(videoWidth, videoHeight)
        if (sourceShortSide > targetShortSide) {
            videoEffects.add(Presentation.createForShortSide(targetShortSide))
        }
        // Cap FPS at 30fps for WhatsApp Status HD sharpness & stability
        videoEffects.add(FrameDropEffect.createDefaultFrameDropEffect(30f))

        val editedMediaItem = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        val encoderFactory = DefaultEncoderFactory.Builder(this)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder()
                    .setBitrate(videoBps)
                    .build()
            )
            .setEnableFallback(true)
            .build()

        val progressHolder = ProgressHolder()
        var progressTicker: Runnable? = null

        val transformer = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    progressTicker?.let { mainHandler.removeCallbacks(it) }
                    activeTransformer = null
                    saveToGallery(outFile)
                    exportedParts.add(
                        ExportedPart(
                            index = partNum,
                            file = outFile,
                            durationMs = seg.endMs - seg.startMs,
                            sizeBytes = outFile.length()
                        )
                    )
                    processSegmentAt(uri, segments, index + 1, exportDir, timestamp)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    progressTicker?.let { mainHandler.removeCallbacks(it) }
                    activeTransformer = null
                    finishProcessingUI()
                    Toast.makeText(
                        this@MainActivity,
                        "Export error on Part $partNum: ${exportException.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })
            .build()

        activeTransformer = transformer
        tvProgressLabel.text = "Encoding Part $partNum of $totalParts... 0%"
        progressBar.progress = 0

        transformer.start(editedMediaItem, outFile.absolutePath)

        progressTicker = object : Runnable {
            override fun run() {
                val t = activeTransformer ?: return
                val state = t.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    val pct = progressHolder.progress.coerceIn(0, 100)
                    progressBar.progress = pct
                    tvProgressLabel.text = "Encoding Part $partNum of $totalParts... $pct%"
                }
                if (state != Transformer.PROGRESS_STATE_NOT_STARTED) {
                    mainHandler.postDelayed(this, 200)
                }
            }
        }
        mainHandler.postDelayed(progressTicker, 250)
    }

    private fun saveToGallery(file: File) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/StatusHD")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: return
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(file).use { input ->
                    input.copyTo(out)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            }
        } catch (_: Exception) {
        }
    }

    private fun onAllSegmentsFinished() {
        finishProcessingUI()
        cardOutput.visibility = View.VISIBLE
        containerParts.removeAllViews()

        for (part in exportedParts) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundResource(R.drawable.bg_subcard)
                setPadding(28, 22, 24, 22)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = 16
                layoutParams = lp
            }

            val sizeMb = part.sizeBytes / (1024.0 * 1024.0)
            val info = TextView(this).apply {
                text = String.format(
                    Locale.US,
                    "Part %d • %s
%.2f MB (HD MP4)",
                    part.index,
                    formatMs(part.durationMs),
                    sizeMb
                )
                setTextColor(getColor(R.color.text_primary))
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
            }

            val btnShare = MaterialButton(this).apply {
                text = "Share WA"
                isAllCaps = false
                setBackgroundColor(getColor(R.color.accent))
                setTextColor(0xFF041B15.toInt())
                setOnClickListener {
                    shareSingleToWhatsApp(part.file)
                }
            }

            row.addView(info)
            row.addView(btnShare)
            containerParts.addView(row)
        }

        btnShareAll.visibility = if (exportedParts.size > 1) View.VISIBLE else View.GONE
        Toast.makeText(
            this,
            "Done! ${exportedParts.size} HD part(s) saved to Gallery.",
            Toast.LENGTH_LONG
        ).show()

        mainHandler.postDelayed({
            mainScroll.fullScroll(View.FOCUS_DOWN)
        }, 150)
    }

    private fun finishProcessingUI() {
        btnOptimize.isEnabled = true
        btnPickVideo.isEnabled = true
        layoutProgress.visibility = View.GONE
    }

    private fun copyCaptionIfPresent(): String {
        val text = etCaption.text.toString().trim()
        if (text.isNotEmpty()) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("WhatsApp Status", text))
        }
        return text
    }

    private fun shareSingleToWhatsApp(file: File) {
        val caption = copyCaptionIfPresent()
        val contentUri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, contentUri)
            if (caption.isNotEmpty()) {
                putExtra(Intent.EXTRA_TEXT, caption)
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            setPackage("com.whatsapp")
        }

        try {
            startActivity(intent)
        } catch (_: Exception) {
            intent.setPackage(null)
            startActivity(Intent.createChooser(intent, "Share HD Status"))
        }
    }

    private fun shareMultipleToWhatsApp(files: List<File>) {
        if (files.isEmpty()) return
        val caption = copyCaptionIfPresent()
        val uris = ArrayList<Uri>()
        for (f in files) {
            uris.add(FileProvider.getUriForFile(this, "${packageName}.fileprovider", f))
        }

        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "video/mp4"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            if (caption.isNotEmpty()) {
                putExtra(Intent.EXTRA_TEXT, caption)
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            setPackage("com.whatsapp")
        }

        try {
            startActivity(intent)
        } catch (_: Exception) {
            intent.setPackage(null)
            startActivity(Intent.createChooser(intent, "Share All HD Status Parts"))
        }
    }

    private fun formatMs(ms: Long): String {
        val safe = max(0L, ms)
        val totalTenths = safe / 100L
        val mins = totalTenths / 600L
        val secs = (totalTenths % 600L) / 10.0
        return String.format(Locale.US, "%d:%04.1f", mins, secs)
    }

    override fun onDestroy() {
        super.onDestroy()
        previewStopRunnable?.let { mainHandler.removeCallbacks(it) }
        activeTransformer?.cancel()
        player?.release()
    }
}

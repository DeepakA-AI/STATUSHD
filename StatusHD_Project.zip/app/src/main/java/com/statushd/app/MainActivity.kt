package com.statushd.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaCodecInfo
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.ui.PlayerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var mainScroll: ScrollView
    private lateinit var etWhatsAppNumber: EditText
    private lateinit var btnSaveNumber: MaterialButton
    private lateinit var btnPickVideo: MaterialButton
    private lateinit var tvVideoInfo: TextView

    private lateinit var cardTrim: LinearLayout
    private lateinit var playerView: PlayerView
    private lateinit var switchManualTrim: SwitchMaterial
    private lateinit var layoutTrimControls: LinearLayout
    private lateinit var tvStartTime: TextView
    private lateinit var tvEndTime: TextView
    private lateinit var seekStart: SeekBar
    private lateinit var seekEnd: SeekBar
    private lateinit var btnSetStartNow: MaterialButton
    private lateinit var btnSetEndNow: MaterialButton
    private lateinit var btnCheckStart: MaterialButton
    private lateinit var btnCheckEnd: MaterialButton

    private lateinit var cardSettings: LinearLayout
    private lateinit var rgQuality: RadioGroup
    private lateinit var rgSplit: RadioGroup
    private lateinit var tvSplitSummary: TextView
    private lateinit var etCaption: EditText
    private lateinit var btnOptimize: MaterialButton
    private lateinit var layoutProgress: LinearLayout
    private lateinit var tvProgressLabel: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var btnCancel: MaterialButton

    private lateinit var cardOutput: LinearLayout
    private lateinit var containerParts: LinearLayout
    private lateinit var btnSendAllSelfChat: MaterialButton
    private lateinit var btnOpenSelfChat: MaterialButton

    private var player: ExoPlayer? = null
    private var selectedUri: Uri? = null
    private var fullDurationMs: Long = 0L
    private var videoWidth: Int = 0
    private var videoHeight: Int = 0
    private var trimStartMs: Long = 0L
    private var trimEndMs: Long = 0L

    private var activeTransformer: Transformer? = null
    private var isCancelled = false
    private val mainHandler = Handler(Looper.getMainLooper())
    private var previewStopRunnable: Runnable? = null

    data class Segment(val startMs: Long, val endMs: Long)
    data class QualityPreset(
        val label: String,
        val isPure1152: Boolean,
        val shortSide: Int,
        val videoBitrateBps: Int
    )
    data class ExportedPart(
        val index: Int,
        val file: File,
        val galleryUri: Uri?,
        val durationMs: Long,
        val sizeBytes: Long
    )

    private val exportedParts = mutableListOf<ExportedPart>()

    companion object {
        private const val PREFS_NAME = "statushd_prefs"
        private const val KEY_WA_NUMBER = "wa_number"
    }

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                loadSelectedVideo(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        loadSavedNumber()
        setupListeners()
    }

    private fun bindViews() {
        mainScroll = findViewById(R.id.mainScroll)
        etWhatsAppNumber = findViewById(R.id.etWhatsAppNumber)
        btnSaveNumber = findViewById(R.id.btnSaveNumber)
        btnPickVideo = findViewById(R.id.btnPickVideo)
        tvVideoInfo = findViewById(R.id.tvVideoInfo)

        cardTrim = findViewById(R.id.cardTrim)
        playerView = findViewById(R.id.playerView)
        switchManualTrim = findViewById(R.id.switchManualTrim)
        layoutTrimControls = findViewById(R.id.layoutTrimControls)
        tvStartTime = findViewById(R.id.tvStartTime)
        tvEndTime = findViewById(R.id.tvEndTime)
        seekStart = findViewById(R.id.seekStart)
        seekEnd = findViewById(R.id.seekEnd)
        btnSetStartNow = findViewById(R.id.btnSetStartNow)
        btnSetEndNow = findViewById(R.id.btnSetEndNow)
        btnCheckStart = findViewById(R.id.btnCheckStart)
        btnCheckEnd = findViewById(R.id.btnCheckEnd)

        cardSettings = findViewById(R.id.cardSettings)
        rgQuality = findViewById(R.id.rgQuality)
        rgSplit = findViewById(R.id.rgSplit)
        tvSplitSummary = findViewById(R.id.tvSplitSummary)
        etCaption = findViewById(R.id.etCaption)
        btnOptimize = findViewById(R.id.btnOptimize)
        layoutProgress = findViewById(R.id.layoutProgress)
        tvProgressLabel = findViewById(R.id.tvProgressLabel)
        progressBar = findViewById(R.id.progressBar)
        btnCancel = findViewById(R.id.btnCancel)

        cardOutput = findViewById(R.id.cardOutput)
        containerParts = findViewById(R.id.containerParts)
        btnSendAllSelfChat = findViewById(R.id.btnSendAllSelfChat)
        btnOpenSelfChat = findViewById(R.id.btnOpenSelfChat)
    }

    private fun loadSavedNumber() {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_WA_NUMBER, "") ?: ""
        if (saved.isNotEmpty()) {
            etWhatsAppNumber.setText(saved)
        }
    }

    private fun normalizeWhatsAppNumber(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        if (digits.isEmpty()) return ""
        return if (digits.length == 10) "91$digits" else digits
    }

    private fun getSavedOrTypedNumber(): String {
        val typed = normalizeWhatsAppNumber(etWhatsAppNumber.text.toString())
        if (typed.isNotEmpty()) {
            val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putString(KEY_WA_NUMBER, typed).apply()
            return typed
        }
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_WA_NUMBER, "") ?: ""
    }

    private fun setupListeners() {
        btnSaveNumber.setOnClickListener {
            val normalized = normalizeWhatsAppNumber(etWhatsAppNumber.text.toString())
            if (normalized.length < 10) {
                Toast.makeText(this, "Enter a valid WhatsApp number (e.g. 9876543210)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putString(KEY_WA_NUMBER, normalized).apply()
            etWhatsAppNumber.setText(normalized)
            Toast.makeText(this, "Saved WhatsApp number: +$normalized", Toast.LENGTH_SHORT).show()
        }

        btnPickVideo.setOnClickListener {
            pickVideoLauncher.launch("video/*")
        }

        switchManualTrim.setOnCheckedChangeListener { _, isChecked ->
            layoutTrimControls.visibility = if (isChecked) View.VISIBLE else View.GONE
            updateSplitSummary()
        }

        seekStart.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val proposed = progress.toLong() * 100L
                trimStartMs = min(proposed, max(0L, trimEndMs - 500L))
                tvStartTime.text = formatMs(trimStartMs)
                player?.pause()
                player?.seekTo(trimStartMs)
                updateSplitSummary()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        seekEnd.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val proposed = progress.toLong() * 100L
                trimEndMs = max(proposed, min(fullDurationMs, trimStartMs + 500L))
                tvEndTime.text = formatMs(trimEndMs)
                player?.pause()
                player?.seekTo(trimEndMs)
                updateSplitSummary()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        btnSetStartNow.setOnClickListener {
            val pos = player?.currentPosition ?: return@setOnClickListener
            if (pos < trimEndMs - 500L) {
                trimStartMs = pos
                seekStart.progress = (trimStartMs / 100L).toInt()
                tvStartTime.text = formatMs(trimStartMs)
                updateSplitSummary()
            } else {
                Toast.makeText(this, "Start must be before End", Toast.LENGTH_SHORT).show()
            }
        }

        btnSetEndNow.setOnClickListener {
            val pos = player?.currentPosition ?: return@setOnClickListener
            if (pos > trimStartMs + 500L) {
                trimEndMs = pos
                seekEnd.progress = (trimEndMs / 100L).toInt()
                tvEndTime.text = formatMs(trimEndMs)
                updateSplitSummary()
            } else {
                Toast.makeText(this, "End must be after Start", Toast.LENGTH_SHORT).show()
            }
        }

        btnCheckStart.setOnClickListener {
            val stopAt = min(trimEndMs, trimStartMs + 5000L)
            playPreviewRange(trimStartMs, stopAt)
        }

        btnCheckEnd.setOnClickListener {
            val startAt = max(trimStartMs, trimEndMs - 4000L)
            playPreviewRange(startAt, trimEndMs)
        }

        rgSplit.setOnCheckedChangeListener { _, _ -> updateSplitSummary() }
        rgQuality.setOnCheckedChangeListener { _, _ -> updateSplitSummary() }

        btnOptimize.setOnClickListener {
            startOptimization()
        }

        btnCancel.setOnClickListener {
            isCancelled = true
            activeTransformer?.cancel()
            activeTransformer = null
            finishProcessingUI()
            Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
        }

        btnSendAllSelfChat.setOnClickListener {
            sendPartsToWhatsApp(exportedParts, toSelfChat = true)
        }

        btnOpenSelfChat.setOnClickListener {
            openSelfChatWindow()
        }
    }

    private fun playPreviewRange(startMs: Long, endMs: Long) {
        val exo = player ?: return
        previewStopRunnable?.let { mainHandler.removeCallbacks(it) }
        exo.seekTo(startMs)
        exo.play()
        val duration = max(300L, endMs - startMs)
        val stopTask = Runnable {
            exo.pause()
        }
        previewStopRunnable = stopTask
        mainHandler.postDelayed(stopTask, duration)
    }

    private fun loadSelectedVideo(uri: Uri) {
        selectedUri = uri
        cardOutput.visibility = View.GONE

        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            fullDurationMs =
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                    ?: 0L
            val w =
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
                    ?: 1080
            val h =
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
                    ?: 1920
            val rot =
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull()
                    ?: 0
            if (rot == 90 || rot == 270) {
                videoWidth = h
                videoHeight = w
            } else {
                videoWidth = w
                videoHeight = h
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Could not read video metadata: ${e.message}", Toast.LENGTH_LONG).show()
            return
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }

        val sizeBytes = queryFileSize(uri)
        val sizeMb = sizeBytes / (1024.0 * 1024.0)
        tvVideoInfo.text = String.format(
            Locale.US,
            "Loaded: %.2f MB • %s • %dx%d",
            sizeMb,
            formatMs(fullDurationMs),
            videoWidth,
            videoHeight
        )

        trimStartMs = 0L
        trimEndMs = fullDurationMs
        val maxTicks = max(1, (fullDurationMs / 100L).toInt())
        seekStart.max = maxTicks
        seekEnd.max = maxTicks
        seekStart.progress = 0
        seekEnd.progress = maxTicks
        tvStartTime.text = formatMs(trimStartMs)
        tvEndTime.text = formatMs(trimEndMs)

        player?.release()
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
        }

        cardTrim.visibility = View.VISIBLE
        cardSettings.visibility = View.VISIBLE
        updateSplitSummary()
    }

    private fun queryFileSize(uri: Uri): Long {
        return try {
            contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
        } catch (_: Exception) {
            0L
        }
    }

    private fun getActiveRange(): Pair<Long, Long> {
        return if (switchManualTrim.isChecked) {
            Pair(trimStartMs, max(trimStartMs + 500L, trimEndMs))
        } else {
            Pair(0L, fullDurationMs)
        }
    }

    private fun getSplitLengthMs(): Long {
        return when (rgSplit.checkedRadioButtonId) {
            R.id.rbSplit90 -> 90_000L
            R.id.rbSplit60 -> 60_000L
            R.id.rbSplit30 -> 30_000L
            else -> Long.MAX_VALUE
        }
    }

    private fun buildSegments(): List<Segment> {
        val (startMs, endMs) = getActiveRange()
        val totalMs = max(500L, endMs - startMs)
        val splitMs = getSplitLengthMs()
        if (splitMs == Long.MAX_VALUE || totalMs <= splitMs) {
            return listOf(Segment(startMs, endMs))
        }
        val list = mutableListOf<Segment>()
        var cursor = startMs
        while (cursor < endMs) {
            val nextEnd = min(cursor + splitMs, endMs)
            if (endMs - nextEnd in 1..999 && list.isNotEmpty()) {
                list.add(Segment(cursor, endMs))
                break
            }
            list.add(Segment(cursor, nextEnd))
            cursor = nextEnd
        }
        return list
    }

    private fun getQualityPreset(): QualityPreset {
        return when (rgQuality.checkedRadioButtonId) {
            R.id.rbPure1152 -> QualityPreset(
                label = "1152×1920 @ 4.0 Mbps",
                isPure1152 = true,
                shortSide = 1152,
                videoBitrateBps = 3_900_000
            )
            R.id.rb1080 -> QualityPreset(
                label = "1080p @ 4.0 Mbps",
                isPure1152 = false,
                shortSide = 1080,
                videoBitrateBps = 3_900_000
            )
            else -> QualityPreset(
                label = "720p @ 2.0 Mbps",
                isPure1152 = false,
                shortSide = 720,
                videoBitrateBps = 2_000_000
            )
        }
    }

    private fun updateSplitSummary() {
        if (fullDurationMs <= 0L) return
        val segments = buildSegments()
        val preset = getQualityPreset()
        val totalBps = preset.videoBitrateBps + 128_000.0
        if (segments.size == 1) {
            val durMs = segments[0].endMs - segments[0].startMs
            val estMb = (totalBps * (durMs / 1000.0)) / (8.0 * 1024.0 * 1024.0)
            tvSplitSummary.text = String.format(
                Locale.US,
                "Output: 1 Single Clip (%s) • %s • Est. ~%.1f MB",
                formatMs(durMs),
                preset.label,
                estMb
            )
            btnOptimize.text = "Create PureHD WhatsApp Status"
        } else {
            val detail = segments.mapIndexed { idx, seg ->
                "P${idx + 1}(${formatMs(seg.startMs)}–${formatMs(seg.endMs)})"
            }.joinToString(", ")
            tvSplitSummary.text = "Output: ${segments.size} HD Parts (${preset.label}) — $detail"
            btnOptimize.text = "Create ${segments.size} PureHD Status Parts"
        }
    }

    private fun startOptimization() {
        val uri = selectedUri ?: return
        player?.pause()

        val segments = buildSegments()
        if (segments.isEmpty()) return

        isCancelled = false
        exportedParts.clear()
        containerParts.removeAllViews()
        cardOutput.visibility = View.GONE
        btnSendAllSelfChat.visibility = View.GONE

        btnOptimize.isEnabled = false
        btnPickVideo.isEnabled = false
        layoutProgress.visibility = View.VISIBLE
        progressBar.progress = 0

        val exportDir = File(cacheDir, "exports").apply {
            if (!exists()) mkdirs()
            listFiles()?.forEach { it.delete() }
        }

        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        processSegmentAt(uri, segments, 0, exportDir, timestamp)
    }

    private fun processSegmentAt(
        uri: Uri,
        segments: List<Segment>,
        index: Int,
        exportDir: File,
        timestamp: String
    ) {
        if (isCancelled) {
            finishProcessingUI()
            return
        }
        if (index >= segments.size) {
            onAllSegmentsFinished()
            return
        }

        val seg = segments[index]
        val partNum = index + 1
        val totalParts = segments.size
        val preset = getQualityPreset()

        val outFile = File(exportDir, "StatusHD_${timestamp}_Part${partNum}.mp4")

        val mediaItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(seg.startMs)
                    .setEndPositionMs(seg.endMs)
                    .build()
            )
            .build()

        val videoEffects = mutableListOf<Effect>()
        if (preset.isPure1152) {
            // Exact PureStatus macroblock-aligned resolution (1152x1920 portrait / 1920x1152 landscape)
            val isPortrait = videoHeight >= videoWidth
            val outW = if (isPortrait) 1152 else 1920
            val outH = if (isPortrait) 1920 else 1152
            videoEffects.add(
                Presentation.createForWidthAndHeight(
                    outW,
                    outH,
                    Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
                )
            )
        } else {
            val sourceShortSide = min(videoWidth, videoHeight)
            if (sourceShortSide > preset.shortSide) {
                videoEffects.add(Presentation.createForShortSide(preset.shortSide))
            }
        }
        // Match PureStatus 30fps ceiling for smooth WhatsApp HD passthrough
        videoEffects.add(FrameDropEffect.createDefaultFrameDropEffect(30f))

        val editedMediaItem = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        // Enforce strict CBR 4.0 Mbps (3.9 Mbps video + ~128 kbps audio = ~4.0 Mbps total)
        val encoderFactory = DefaultEncoderFactory.Builder(this)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder()
                    .setBitrate(preset.videoBitrateBps)
                    .setBitrateMode(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR)
                    .build()
            )
            .setEnableFallback(true)
            .build()

        val progressHolder = ProgressHolder()
        var progressTicker: Runnable? = null

        val transformer = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    progressTicker?.let { mainHandler.removeCallbacks(it) }
                    activeTransformer = null
                    val savedGalleryUri = saveToGallery(outFile)
                    exportedParts.add(
                        ExportedPart(
                            index = partNum,
                            file = outFile,
                            galleryUri = savedGalleryUri,
                            durationMs = seg.endMs - seg.startMs,
                            sizeBytes = outFile.length()
                        )
                    )
                    processSegmentAt(uri, segments, index + 1, exportDir, timestamp)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    progressTicker?.let { mainHandler.removeCallbacks(it) }
                    activeTransformer = null
                    finishProcessingUI()
                    Toast.makeText(
                        this@MainActivity,
                        "Export error on Part $partNum: ${exportException.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            })
            .build()

        activeTransformer = transformer
        tvProgressLabel.text = "Encoding Part $partNum of $totalParts... 0%"
        progressBar.progress = 0

        transformer.start(editedMediaItem, outFile.absolutePath)

        progressTicker = object : Runnable {
            override fun run() {
                val t = activeTransformer ?: return
                val state = t.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    val pct = progressHolder.progress.coerceIn(0, 100)
                    progressBar.progress = pct
                    tvProgressLabel.text = "Encoding Part $partNum of $totalParts... $pct%"
                }
                if (state != Transformer.PROGRESS_STATE_NOT_STARTED) {
                    mainHandler.postDelayed(this, 200)
                }
            }
        }
        mainHandler.postDelayed(progressTicker, 250)
    }

    private fun saveToGallery(file: File): Uri? {
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/StatusHD")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: return null
            contentResolver.openOutputStream(uri)?.use { out ->
                FileInputStream(file).use { input ->
                    input.copyTo(out)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            }
            uri
        } catch (_: Exception) {
            null
        }
    }

    private fun onAllSegmentsFinished() {
        finishProcessingUI()
        cardOutput.visibility = View.VISIBLE
        containerParts.removeAllViews()

        for (part in exportedParts) {
            val block = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(R.drawable.bg_subcard)
                setPadding(24, 20, 24, 20)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = 16
                layoutParams = lp
            }

            val sizeMb = part.sizeBytes / (1024.0 * 1024.0)
            val durSec = max(0.1, part.durationMs / 1000.0)
            val actualMbps = (part.sizeBytes * 8.0 / durSec) / 1_000_000.0
            val info = TextView(this).apply {
                text = String.format(
                    Locale.US,
                    "Part %d • %s • %.2f MB (~%.2f Mbps)",
                    part.index,
                    formatMs(part.durationMs),
                    sizeMb,
                    actualMbps
                )
                setTextColor(getColor(R.color.text_primary))
                textSize = 13f
            }

            val btnRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = 12
                layoutParams = lp
            }

            val btnSelfChat = MaterialButton(this).apply {
                text = "Send to My Chat"
                isAllCaps = false
                setBackgroundColor(getColor(R.color.accent))
                setTextColor(0xFF041B15.toInt())
                textSize = 12f
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.3f)
                lp.marginEnd = 10
                layoutParams = lp
                setOnClickListener {
                    sendPartsToWhatsApp(listOf(part), toSelfChat = true)
                }
            }

            val btnShareAny = MaterialButton(this).apply {
                text = "Share WA"
                isAllCaps = false
                setBackgroundColor(getColor(R.color.border_dark))
                setTextColor(getColor(R.color.text_primary))
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    sendPartsToWhatsApp(listOf(part), toSelfChat = false)
                }
            }

            btnRow.addView(btnSelfChat)
            btnRow.addView(btnShareAny)
            block.addView(info)
            block.addView(btnRow)
            containerParts.addView(block)
        }

        btnSendAllSelfChat.visibility = if (exportedParts.size > 1) View.VISIBLE else View.GONE
        Toast.makeText(
            this,
            "Done! ${exportedParts.size} PureHD part(s) saved to Gallery.",
            Toast.LENGTH_LONG
        ).show()

        mainHandler.postDelayed({
            mainScroll.fullScroll(View.FOCUS_DOWN)
        }, 150)
    }

    private fun finishProcessingUI() {
        btnOptimize.isEnabled = true
        btnPickVideo.isEnabled = true
        layoutProgress.visibility = View.GONE
    }

    private fun copyCaptionIfPresent(): String {
        val text = etCaption.text.toString().trim()
        if (text.isNotEmpty()) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("WhatsApp Status", text))
        }
        return text
    }

    private fun resolveShareUri(part: ExportedPart): Uri {
        return part.galleryUri ?: FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            part.file
        )
    }

    private fun detectWhatsAppPackage(): String? {
        val candidates = listOf("com.whatsapp", "com.whatsapp.w4b")
        for (pkg in candidates) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    packageManager.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    packageManager.getPackageInfo(pkg, 0)
                }
                return pkg
            } catch (_: Exception) {
            }
        }
        return null
    }

    private fun sendPartsToWhatsApp(parts: List<ExportedPart>, toSelfChat: Boolean) {
        if (parts.isEmpty()) return

        val waNumber = if (toSelfChat) getSavedOrTypedNumber() else ""
        if (toSelfChat && waNumber.length < 10) {
            Toast.makeText(
                this,
                "Please enter and Save your WhatsApp number at the top first.",
                Toast.LENGTH_LONG
            ).show()
            mainScroll.fullScroll(View.FOCUS_UP)
            return
        }

        val caption = copyCaptionIfPresent()
        val uris = ArrayList<Uri>()
        for (p in parts) {
            uris.add(resolveShareUri(p))
        }

        val waPkg = detectWhatsAppPackage()
        val isMultiple = uris.size > 1

        val intent = Intent(if (isMultiple) Intent.ACTION_SEND_MULTIPLE else Intent.ACTION_SEND).apply {
            type = "video/mp4"
            if (isMultiple) {
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            } else {
                putExtra(Intent.EXTRA_STREAM, uris[0])
            }
            if (caption.isNotEmpty()) {
                putExtra(Intent.EXTRA_TEXT, caption)
            }
            if (toSelfChat && waNumber.isNotEmpty()) {
                putExtra("jid", "$waNumber@s.whatsapp.net")
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

            val clip = ClipData.newUri(contentResolver, "StatusHD Video", uris[0])
            for (i in 1 until uris.size) {
                clip.addItem(ClipData.Item(uris[i]))
            }
            clipData = clip

            if (waPkg != null) {
                setPackage(waPkg)
            }
        }

        try {
            startActivity(intent)
        } catch (_: Exception) {
            intent.setPackage(null)
            intent.removeExtra("jid")
            startActivity(Intent.createChooser(intent, "Share HD Status"))
        }
    }

    private fun openSelfChatWindow() {
        val waNumber = getSavedOrTypedNumber()
        if (waNumber.length < 10) {
            Toast.makeText(
                this,
                "Enter your WhatsApp number at the top first.",
                Toast.LENGTH_SHORT
            ).show()
            mainScroll.fullScroll(View.FOCUS_UP)
            return
        }
        copyCaptionIfPresent()
        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$waNumber")
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            detectWhatsAppPackage()?.let { setPackage(it) }
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }

    private fun formatMs(ms: Long): String {
        val safe = max(0L, ms)
        val totalTenths = safe / 100L
        val mins = totalTenths / 600L
        val secs = (totalTenths % 600L) / 10.0
        return String.format(Locale.US, "%d:%04.1f", mins, secs)
    }

    override fun onDestroy() {
        super.onDestroy()
        previewStopRunnable?.let { mainHandler.removeCallbacks(it) }
        activeTransformer?.cancel()
        player?.release()
    }
}

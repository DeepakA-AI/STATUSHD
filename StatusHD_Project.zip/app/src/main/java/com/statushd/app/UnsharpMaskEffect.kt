package com.statushd.app

import android.content.Context
import android.opengl.GLES20
import androidx.annotation.OptIn
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

@OptIn(UnstableApi::class)
class UnsharpMaskEffect(private val sharpness: Float = 0.60f) : GlEffect {

    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        return UnsharpMaskShaderProgram(useHdr, sharpness)
    }

    override fun isNoOp(inputWidth: Int, inputHeight: Int): Boolean {
        return sharpness <= 0.01f
    }
}

@OptIn(UnstableApi::class)
private class UnsharpMaskShaderProgram(
    useHdr: Boolean,
    sharpness: Float
) : BaseGlShaderProgram(useHdr, 1) {

    private val glProgram: GlProgram

    init {
        try {
            glProgram = GlProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }

        glProgram.setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
        )
        glProgram.setFloatUniform("uSharpness", sharpness)
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        val safeW = if (inputWidth > 0) inputWidth else 1080
        val safeH = if (inputHeight > 0) inputHeight else 1920
        glProgram.setFloatUniform("uTexelWidth", 1.0f / safeW.toFloat())
        glProgram.setFloatUniform("uTexelHeight", 1.0f / safeH.toFloat())
        return Size(safeW, safeH)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    companion object {
        private const val VERTEX_SHADER =
            "attribute vec4 aFramePosition;\n" +
            "varying vec2 vTexSamplingCoord;\n" +
            "void main() {\n" +
            "  gl_Position = aFramePosition;\n" +
            "  vTexSamplingCoord = vec2(aFramePosition.x * 0.5 + 0.5, aFramePosition.y * 0.5 + 0.5);\n" +
            "}\n"

        private const val FRAGMENT_SHADER =
            "precision highp float;\n" +
            "uniform sampler2D uTexSampler;\n" +
            "uniform float uTexelWidth;\n" +
            "uniform float uTexelHeight;\n" +
            "uniform float uSharpness;\n" +
            "varying vec2 vTexSamplingCoord;\n" +
            "void main() {\n" +
            "  vec4 center = texture2D(uTexSampler, vTexSamplingCoord);\n" +
            "  vec3 c = center.rgb;\n" +
            "  vec3 n = texture2D(uTexSampler, vTexSamplingCoord + vec2(0.0, uTexelHeight)).rgb;\n" +
            "  vec3 s = texture2D(uTexSampler, vTexSamplingCoord - vec2(0.0, uTexelHeight)).rgb;\n" +
            "  vec3 e = texture2D(uTexSampler, vTexSamplingCoord + vec2(uTexelWidth, 0.0)).rgb;\n" +
            "  vec3 w = texture2D(uTexSampler, vTexSamplingCoord - vec2(uTexelWidth, 0.0)).rgb;\n" +
            "  vec3 blur = (n + s + e + w) * 0.25;\n" +
            "  vec3 detail = c - blur;\n" +
            "  vec3 minRgb = min(c, min(min(n, s), min(e, w)));\n" +
            "  vec3 maxRgb = max(c, max(max(n, s), max(e, w)));\n" +
            "  vec3 contrast = maxRgb - minRgb;\n" +
            "  float maxContrast = max(contrast.r, max(contrast.g, contrast.b));\n" +
            "  float edgeMask = 1.0 - smoothstep(0.25, 0.75, maxContrast);\n" +
            "  float gain = uSharpness * (0.35 + 0.65 * edgeMask);\n" +
            "  vec3 sharpened = clamp(c + detail * gain, 0.0, 1.0);\n" +
            "  gl_FragColor = vec4(sharpened, center.a);\n" +
            "}\n"
    }
}

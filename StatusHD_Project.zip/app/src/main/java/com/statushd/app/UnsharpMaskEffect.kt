package com.statushd.app

import android.content.Context
import android.opengl.GLES20
import androidx.annotation.OptIn
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram
import java.io.IOException

@OptIn(UnstableApi::class)
class UnsharpMaskEffect(private val sharpness: Float = 0.60f) : GlEffect {

    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram {
        return UnsharpMaskShaderProgram(context, useHdr, sharpness)
    }

    override fun isNoOp(inputWidth: Int, inputHeight: Int): Boolean {
        return sharpness <= 0.01f
    }
}

@OptIn(UnstableApi::class)
private class UnsharpMaskShaderProgram(
    context: Context,
    useHdr: Boolean,
    sharpness: Float
) : BaseGlShaderProgram(useHdr, 1) {

    private val glProgram: GlProgram

    init {
        try {
            glProgram = GlProgram(
                context,
                R.raw.vertex_shader_sharpen,
                R.raw.fragment_shader_sharpen
            )
        } catch (e: IOException) {
            throw VideoFrameProcessingException(e)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }

        glProgram.setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
        )
        glProgram.setFloatUniform("uSharpness", sharpness)
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        val safeW = if (inputWidth > 0) inputWidth else 1080
        val safeH = if (inputHeight > 0) inputHeight else 1920
        glProgram.setFloatUniform("uTexelWidth", 1.0f / safeW.toFloat())
        glProgram.setFloatUniform("uTexelHeight", 1.0f / safeH.toFloat())
        return Size(safeW, safeH)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }
}
